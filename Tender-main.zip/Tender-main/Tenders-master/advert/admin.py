from django.contrib import admin
from .models import Advert, Item

# Register your models here.
admin.site.register(Advert)
admin.site.register(Item)

