We plan to add features like recommendations for the service provider
as soon as the tender is posted and also verify the legitimacy of the
businesses' listings.